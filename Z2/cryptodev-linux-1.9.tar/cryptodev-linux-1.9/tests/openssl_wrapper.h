#ifndef __OPENSSL_WRAPPER_H
#define __OPENSSL_WRAPPER_H

int openssl_cioccrypt(struct session_op *, struct crypt_op *);

#endif /* __OPENSSL_WRAPPER_H */
